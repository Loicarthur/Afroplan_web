
  # Site Web Afro Plan

  This is a code bundle for Site Web Afro Plan. The original project is available at https://www.figma.com/design/09Lgx19I3p8EJ65x0bF2gN/Site-Web-Afro-Plan.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  